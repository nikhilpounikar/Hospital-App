# Emplyee_Review_APP

# npm init ==> initialise packge.json
# npm install express ==> install express and node module folder
# npm install cookie-parser ==> to parse the cookies
# npm install ejs ===> to install view engine
# npm install express-ejs-layouts ===> to install view engine layouts
# npm install express express-static ===> to render static files
# npm install express-session ===> Express Session provides a simple and convenient way to handle sessions 
# npm install mongodb ===> MongoDB Node.js driver
# npm install mongo-connect ===> standard library in the context of MongoDB and Node.js 
# or npm i connect-mongodb-session 
# npm install 
# npm install mongoose ===> Mongoose is a popular object data modeling (ODM) library for Node.js and MongoDB.
# npm install cookie-parser